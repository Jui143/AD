package com.example.ad_expt_4;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class DisplayActivity extends AppCompatActivity {
    private TextView subjectTextView, genderTextView, qualificationsTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        subjectTextView = findViewById(R.id.subjectTextView);
        genderTextView = findViewById(R.id.genderTextView);
        qualificationsTextView = findViewById(R.id.qualificationsTextView);
        // Retrieve data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("RegistrationData", MODE_PRIVATE);
        String subject = sharedPreferences.getString("subject", "No subject selected");
        String gender = sharedPreferences.getString("gender", "No gender selected");
        String qualifications = sharedPreferences.getString("qualifications", "No qualifications selected");

        // Display the data
        subjectTextView.setText("Subject: " + subject);
        genderTextView.setText("Gender: " + gender);
        qualificationsTextView.setText("Qualifications: " + qualifications);
    }
}

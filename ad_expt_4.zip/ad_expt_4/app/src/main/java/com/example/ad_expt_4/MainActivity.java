package com.example.ad_expt_4;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner subjectSpinner;
    private RadioGroup genderRadioGroup;
    private CheckBox qualification1, qualification2;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        subjectSpinner = findViewById(R.id.subjectSpinner);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        qualification1 = findViewById(R.id.qualificationCheckbox1);
        qualification2 = findViewById(R.id.qualificationCheckbox2);
        submitButton = findViewById(R.id.submitButton);

        // Handle button click
        submitButton.setOnClickListener(v -> {
            String subject = subjectSpinner.getSelectedItem().toString();
            int selectedGenderId = genderRadioGroup.getCheckedRadioButtonId();
            RadioButton selectedGenderButton = findViewById(selectedGenderId);
            String gender = selectedGenderButton.getText().toString();
            String qualifications = "";
            if (qualification1.isChecked()) qualifications += "Bachelors ";
            if (qualification2.isChecked()) qualifications += "Masters";

            // Save data using SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("RegistrationData", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("subject", subject);
            editor.putString("gender", gender);
            editor.putString("qualifications", qualifications);
            editor.apply();

            // Start ShowActivity
            Intent intent = new Intent(MainActivity.this, DisplayActivity.class);


            startActivity(intent);
        });
    }
}

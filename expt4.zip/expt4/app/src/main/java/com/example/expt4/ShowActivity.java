package com.example.expt4;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ShowActivity extends AppCompatActivity {

    private TextView nameTextView, subjectTextView, genderTextView, qualificationTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        // Initialize Views
        nameTextView = findViewById(R.id.nameTextView);
        subjectTextView = findViewById(R.id.subjectTextView);
        genderTextView = findViewById(R.id.genderTextView);
        qualificationTextView = findViewById(R.id.qualificationTextView);

        // Retrieve Data from Intent
        String name = getIntent().getStringExtra("name");
        String subject = getIntent().getStringExtra("subject");
        String gender = getIntent().getStringExtra("gender");
        String qualifications = getIntent().getStringExtra("qualifications");

        // Display Data
        nameTextView.setText("Name: " + name);
        subjectTextView.setText("Subject: " + subject);
        genderTextView.setText("Gender: " + gender);
        qualificationTextView.setText("Qualifications: " + qualifications);
    }
}


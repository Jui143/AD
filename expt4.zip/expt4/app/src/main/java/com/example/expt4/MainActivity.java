package com.example.expt4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText;
    private Spinner subjectSpinner;
    private RadioGroup genderRadioGroup;
    private CheckBox graduateCheckBox, postGraduateCheckBox, diplomaCheckBox;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        nameEditText = findViewById(R.id.nameEditText);
        subjectSpinner = findViewById(R.id.subjectSpinner);
        genderRadioGroup = findViewById(R.id.genderRadioGroup);
        graduateCheckBox = findViewById(R.id.graduateCheckBox);
        postGraduateCheckBox = findViewById(R.id.postGraduateCheckBox);
        diplomaCheckBox = findViewById(R.id.diplomaCheckBox);
        submitButton = findViewById(R.id.submitButton);

        // Spinner population
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                new String[]{"JAVA", "OS", "History", "Computer Science", "DSA"}
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(adapter);

        // Default pre-select "Male" RadioButton and "Graduate" CheckBox
        genderRadioGroup.check(R.id.maleRadioButton);
        graduateCheckBox.setChecked(true);

        // Submit Button Listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();

                // Validate Name
                if (name.isEmpty() || !name.matches("[a-zA-Z ]+")) {
                    nameEditText.setError("Please enter a valid name (letters and spaces only)");
                    nameEditText.requestFocus();
                    return;
                }

                // Validate Subject Selection
                String subject = subjectSpinner.getSelectedItem().toString();
                if (subject.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please select a subject", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Validate Gender
                int selectedGenderId = genderRadioGroup.getCheckedRadioButtonId();
                if (selectedGenderId == -1) {
                    Toast.makeText(MainActivity.this, "Please select gender", Toast.LENGTH_SHORT).show();
                    return;
                }
                String gender = ((RadioButton) findViewById(selectedGenderId)).getText().toString();

                // Validate Qualifications
                StringBuilder qualifications = new StringBuilder();
                if (graduateCheckBox.isChecked()) qualifications.append("Graduate ");
                if (postGraduateCheckBox.isChecked()) qualifications.append("Post Graduate ");
                if (diplomaCheckBox.isChecked()) qualifications.append("Diploma ");
                if (qualifications.length() == 0) {
                    Toast.makeText(MainActivity.this, "Please select at least one qualification", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Pass data to next activity
                Intent intent = new Intent(MainActivity.this, ShowActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("subject", subject);
                intent.putExtra("gender", gender);
                intent.putExtra("qualifications", qualifications.toString().trim());
                startActivity(intent);
            }
        });
    }
}

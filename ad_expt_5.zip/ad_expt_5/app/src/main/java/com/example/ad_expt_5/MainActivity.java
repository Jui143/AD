package com.example.ad_expt_5;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Button to show AlertDialog
        Button buttonShowAlertDialog = findViewById(R.id.buttonShowAlertDialog);
        buttonShowAlertDialog.setOnClickListener(v -> showAlertDialog());

        // Button to show ProgressDialog
        Button buttonShowProgressDialog = findViewById(R.id.buttonShowProgressDialog);
        buttonShowProgressDialog.setOnClickListener(v -> showProgressDialog());

        // Button to show PopupMenu
        Button buttonShowPopupMenu = findViewById(R.id.buttonShowPopupMenu);
        buttonShowPopupMenu.setOnClickListener(this::showPopupMenu);

        // Button to show ContextMenu
        Button buttonShowContextMenu = findViewById(R.id.buttonShowContextMenu);
        registerForContextMenu(buttonShowContextMenu); // Register the button for context menu
    }

    // Method to show AlertDialog
    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Alert Dialog")
                .setMessage("Do you want to continue?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Handle Yes button click
                    Toast.makeText(MainActivity.this, "Yes clicked", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", (dialog, which) -> {
                    // Handle No button click
                    Toast.makeText(MainActivity.this, "No clicked", Toast.LENGTH_SHORT).show();
                })
                .create()
                .show();
    }

    // Method to show ProgressDialog
    private void showProgressDialog() {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false); // Can't dismiss by tapping outside
        progressDialog.show();
// Simulate some background task, dismiss after 3 seconds
        new Thread(() -> {
            try {
                Thread.sleep(3000); // Simulate task
            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.d("error", "Error occured in background task", e);
            }
            runOnUiThread(() -> progressDialog.dismiss()); // Dismiss the dialog after task completes
        }).start();
    }

    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        // Create the popup menu
        PopupMenu popupMenu = new PopupMenu(MainActivity.this, view);

        // Inflate the menu resource
        getMenuInflater().inflate(R.menu.menu_popup, popupMenu.getMenu());

        // Set listener for menu item clicks
        popupMenu.setOnMenuItemClickListener(item -> {
            // Handle click events for each menu item using if-else
            if (item.getItemId() == R.id.action_edit) {
                Toast.makeText(MainActivity.this, "Edit clicked", Toast.LENGTH_SHORT).show();
                return true; // Indicates the event was handled
            } else if (item.getItemId() == R.id.action_delete) {
                Toast.makeText(MainActivity.this, "Delete clicked", Toast.LENGTH_SHORT).show();
                return true; // Indicates the event was handled
            } else {
                return false; // Default case to handle unknown items
            }
        });

        // Show the popup menu
        popupMenu.show();
    }

    // Method to create context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_context, menu);
    }

    // Handle context menu item selection
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        // Handle item selection using if-else
        if (item.getItemId() == R.id.action_copy) {
            Toast.makeText(this, "Copy clicked", Toast.LENGTH_SHORT).show();
            return true; // Indicates the event was handled
        } else if (item.getItemId() == R.id.action_paste) {
            Toast.makeText(this, "Paste clicked", Toast.LENGTH_SHORT).show();
            return true; // Indicates the event was handled
        } else {
            return super.onContextItemSelected(item); // Default case calls the parent method
        }
    }
    }


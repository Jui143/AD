package com.example.expt3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
public class HomeActivity extends AppCompatActivity {
    TextView welcomeText;
    Button logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        welcomeText = findViewById(R.id.welcomeText);
        String username = getIntent().getStringExtra("username");
        welcomeText.setText("Welcome, " + username + "!");
    }}
